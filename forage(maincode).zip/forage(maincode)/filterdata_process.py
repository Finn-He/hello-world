import psycopg2, db_details
from flask import Flask,url_for,session, redirect, flash


dbconn = None
def getCursor():
    global dbconn
    if dbconn == None:
        conn = psycopg2.connect(dbname=db_details.dbname, user=db_details.dbuser, password=db_details.dbpass, host=db_details.dbhost, port=db_details.dbport)
        conn.autocommit = True
        dbconn = conn.cursor()
        return dbconn
    else:
        return dbconn


def basicDataProcess(startdata, enddata, region, site, species):
    cur = getCursor()
    siteid_list = []
    for item_si in site:
        sql_1 = 'SELECT id FROM site WHERE region =\'%s\' and sitename =\'%s\';'%(region.strip(),item_si.strip())
        cur.execute(sql_1)
        site_tuple = cur.fetchone()
        siteid_list.append(site_tuple[0])
 
    # select all experiment id in the position
    experiment_list = []
    for id_si in siteid_list:
        sql_2 = 'SELECT Id FROM Experiment WHERE siteid = %s and StartDate >= \'%s\' and EndDate <= \'%s\''%(id_si,startdata,enddata)
        cur.execute(sql_2)
        experiment_tuple = cur.fetchall()
        temporary_site = [j for i in experiment_tuple for j in i]
        experiment_list.extend(temporary_site)

    # filter the experimentid based on species
    list_1 = []
    for item in experiment_list:
        sql_3 = 'SELECT ExperimentId, concat(species,Cultivar,floweringdate,otherspecies,othercultivar,rainfedirrigated,\
                    irrigationlevel,kgpyr,kgnyr,kgkyr,kgsyr,kglimeyr,defoliationmethod,harvestmethod,soiltypes,pasturecrop,\
                    residentsown,sowingdate,otherinfo), species FROM OtherInfo WHERE ExperimentId=%s and Species=\'%s\''%(item,species.strip())
        cur.execute(sql_3)
        unit_tuple = cur.fetchone()
        list_1.append(unit_tuple) 
            
    list_1 = list(filter(None, list_1))  # remove all None in the list

    return list_1, experiment_list

def idClassify(listitem):
    # give each id a list   e.g. [[id1],[id2],[id3].......[idn]]
    alist=[]
    for i in range(0,len(listitem)):
        alist.append([listitem[i][0]])
    
    # Reclassify , compare the second item of each unit, if they are same, put them together in a common list, 
    # this step will generate two lists for one object we want that have different sequence but same elements.
    t = 0
    while t < len(listitem):
        for j in range(0,len(listitem)):
            if t != j and listitem[t][1] == listitem[j][1]:
                alist[t].append(listitem[j][0])
        t = t + 1

    # make two lists that have different sequence but same elements become two same lists by resort the sequence of the elements of the lists.
    blist = []
    for item in alist:
        blist.append(sorted(item))
    
    # remove duplicates and got the Nested list e.g. [[ida1,ida2,ida3...],[idb1,idb2,idb3...],[idc1,idc2,idc3...]....[idn1,idn2,idn3...]]
    # each small list in the big list represent the same conditional experiment Id, the data of them should in a same series.
    clist = []
    [clist.append(y) for y in blist if not y in clist]
    return clist

def basicDataProcess_csv(allSitesString, csvSiteIdsString, startdata, enddata, region, species):
    cur = getCursor()
    # ensure the position
    siteid_list = []

    cur.execute('SELECT DISTINCT id FROM site WHERE region =\'%s\' and siteName IN (%s) and id in (%s);'%(region.strip(), allSitesString, csvSiteIdsString))
    siteid_list = cur.fetchall()
    siteid_list = [j for i in siteid_list for j in i]

    # select all experiment id in the position
    experiment_list = []
    siteid_list_string = ",".join("'{0}'".format(n) for n in siteid_list)
    sql_2 = 'SELECT Id FROM Experiment WHERE siteid in (%s) and StartDate >= \'%s\' and EndDate <= \'%s\''%(siteid_list_string,startdata,enddata)
    cur.execute(sql_2)
    experiment_tuple = cur.fetchall()
    temporary_site = [j for i in experiment_tuple for j in i]
    experiment_list.extend(temporary_site)

    # filter the experimentid based on species
    list_1 = []
    for item in experiment_list:
        sql_3 = 'SELECT ExperimentId, concat(species,Cultivar,floweringdate,otherspecies,othercultivar,rainfedirrigated,\
                    irrigationlevel,kgpyr,kgnyr,kgkyr,kgsyr,kglimeyr,defoliationmethod,harvestmethod,soiltypes,pasturecrop,\
                    residentsown,sowingdate,otherinfo), species FROM OtherInfo WHERE ExperimentId=%s and Species=\'%s\''%(item,species.strip())
        cur.execute(sql_3)
        unit_tuple = cur.fetchone()
        list_1.append(unit_tuple) 
            
    list_1 = list(filter(None, list_1))  # remove all None in the list

    return list_1, experiment_list
       
