import datetime as dt
from datetime import datetime, timedelta, date 



def datelist(start, end):
    datestart=dt.datetime.strptime(start,'%Y-%m-%d')
    dateend=dt.datetime.strptime(end,'%Y-%m-%d')
    data_list = []
    while datestart < dateend:       
        data_list.append(datestart.strftime('%Y-%m-%d'))
        datestart += dt.timedelta(days=1)
    checklist = []
    syear = int(start[:4])
    eyear = int(end[:4])
    for i in range(syear, eyear+1):
        unit = str(i) + '-06-30'
        checklist.append(unit)
    sixthirty = [j for j in checklist if j in data_list]    
    return sixthirty
    
def datedoublelist(start1, end1):
    datestart1=dt.datetime.strptime(start1,'%Y-%m-%d')
    dateend1=dt.datetime.strptime(end1,'%Y-%m-%d')
    data_doublelist1 = list()
    while datestart1 < dateend1:            
        data_doublelist1.append([datestart1.strftime('%Y-%m-%d')])
        datestart1 += dt.timedelta(days=1)
    return data_doublelist1

def durationdays(start2, end2):
    datestart2=dt.datetime.strptime(start2,'%Y-%m-%d')
    dateend2=dt.datetime.strptime(end2,'%Y-%m-%d')
    day_number = (dateend2 - datestart2).days
    return day_number

def datedoublelist_2(start3, end3):
    datestart3=dt.datetime.strptime(start3,'%Y-%m-%d')
    dateend3=dt.datetime.strptime(end3,'%Y-%m-%d')
    stdate = datestart3 + dt.timedelta(days=1)
    data_doublelist3= list()
    while datestart3 <= dateend3:           
        data_doublelist3.append([stdate.strftime('%Y-%m-%d')])
        datestart3 += dt.timedelta(days=1)
    return data_doublelist3