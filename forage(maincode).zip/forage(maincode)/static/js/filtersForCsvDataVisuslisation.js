function onFileUpload(){
    document.getElementById("allSiteIds").textContent=""
}

$(function() {
    $("#region").change(function() {
        $("#species").empty()
        $("#sitesCheckBoxes").empty()
        $("#startDate").val(null)
        $("#endDate").val(null)      

        $.ajax({
            url: '/get_species_for_csv_graphing',
            data: {
                region: $("#region").val(),
                allSiteIds: JSON.stringify($("#allSiteIds").text())
            },
            type: 'POST',
            success: function(data) {
                allSpecies = data.split(',')
                if(allSpecies.length){
                    $("#species").prop('disabled', false);
                    $('#species').append($('<option>', { 
                        text : 'Select Species' 
                    }))
                    allSpecies.forEach(function(item) {
                        $('#species').append($('<option>', { 
                            value: item,
                            text : item 
                        }))
                    })
                }
            },
            error: function(error) {
                console.log(error);
            }
        });
    });

    $("#species").change(function() {
        $("#sitesCheckBoxes").empty()
        $("#startDate").val(null)
        $("#endDate").val(null)

        $.ajax({
            url: '/get_sites_for_csv_graphing',
            data: {
                species: $("#species").val(),
                region: $("#region").val(),
                allSiteIds: JSON.stringify($("#allSiteIds").text())
            },
            type: 'POST',
            success: function(data) {
                allSites = data.split(',')
                if(allSites.length){
                    $("#sites").prop('disabled', false);
                    $('#sitesCheckBoxes').append($('<option>', { 
                        text : 'Select Sites' 
                    }))
                    allSites.forEach(function(item) {
                        $('#sitesCheckBoxes').append("<label> " + 
                        "<input value='"+ item +"'type='checkbox' name='sitesCheckBoxes' class='ml-1' />" 
                        + item 
                        + "</label> ");
                    })

                }
            },
            error: function(error) {
                console.log(error);
            }
        });
    });

    $("#sitesCheckBoxes").change(function() {
        $("#startDate").val(null)
        $("#endDate").val(null)
        var allSites = $('input[name=sitesCheckBoxes]:checked').map(function()
            {
                return $(this).val();
            }).get();

        $.ajax({
            url: '/get_Dates_for_csv_graphing',
            data: {
                species: $("#species").val(),
                allSites: JSON.stringify(allSites),
                region: $("#region").val(),
                allSiteIds: JSON.stringify($("#allSiteIds").text())

            },
            type: 'POST',
            success: function(data) {
                dates = data.split(',')
                if(dates.length){
                    $("#startDate").prop('disabled', false);
                    $("#endDate").prop('disabled', false);
                    var startDate = new Date(dates[0])
                    var endDate = new Date(dates[1])
                    const formattedStartDate = startDate.toISOString().slice(0, 10);
                    const formattedEndDate = endDate.toISOString().slice(0, 10);
                    $("#startDate").val(formattedStartDate);
                    $("#endDate").val(formattedEndDate);
                }

            },
            error: function(error) {
                console.log(error);
            }
        });
    });
});