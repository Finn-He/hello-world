function clickToDisplay(id) {
    let element = document.getElementById(id);
    if (element.style.display === 'block') {
        element.style.display = 'none';
    } else {
        element.style.display = 'block';
    }
}

function showAllSpeciesCheckboxes() {
    clickToDisplay('speciesCheckBoxes');
}

function showSitesCheckboxes() {
    clickToDisplay('sitesCheckBoxes');
}

function validateEndDate() {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    let endDateErrorMsg = document.getElementById('end-date-error-message')
    let submitBtn = document.getElementById('submit-btn')

    if (Date.parse(startDate) > Date.parse(endDate)) {
        endDateErrorMsg.style.display = 'block';
        submitBtn.disabled = true;
    } else {
        endDateErrorMsg.style.display = 'none';
        submitBtn.disabled = false;
    }
}