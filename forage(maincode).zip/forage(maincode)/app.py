from flask import Flask,url_for,session, redirect, flash,render_template,request,jsonify
import psycopg2, db_details
from psycopg2.extras import RealDictCursor
import uuid
import re
import random, string
import datetime as dt
from datetime import datetime, timedelta, date 
from dateprcess_package import datelist, datedoublelist, durationdays, datedoublelist_2
from filterdata_process import basicDataProcess, idClassify, basicDataProcess_csv
import json
from takecsv import *
import csv_upload
import operator
from collections import defaultdict
from decimal import Decimal
from werkzeug.utils import secure_filename
import json
import copy
import os
from datetime import datetime, timedelta, date 
from id_to_info import *
from info_to_linedata import *

# functions for connecting to database and get ready for interaction via psycopg2
# First way of returning database query results: realdict 
dbconnRealDict = None     
def getRealCursor():
    global dbconnRealDict
    if dbconnRealDict == None:
        connRealDict = psycopg2.connect(dbname=db_details.dbname, user=db_details.dbuser,password=db_details.dbpass, host=db_details.dbhost, port=db_details.dbport)
        connRealDict.autocommit = True
        dbconnRealDict = connRealDict.cursor(cursor_factory=RealDictCursor)
        return dbconnRealDict
    else:
        return dbconnRealDict


#second way of returning database query results: array
dbconn = None
def getCursor():
    global dbconn
    if dbconn == None:
        conn = psycopg2.connect(dbname=db_details.dbname, user=db_details.dbuser, password=db_details.dbpass, host=db_details.dbhost, port=db_details.dbport)
        conn.autocommit = True
        dbconn = conn.cursor()
        return dbconn
    else:
        return dbconn


#function for generating random string used for password etc. if needed
def randStr(chars = string.ascii_lowercase + string.digits, N=8):
	return ''.join(random.choice(chars) for _ in range(N))


app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'temp'

#for session dict access
app.secret_key = 'project forage'

def removeSpecialChars(value):
    value = str(value).replace("('",'')
    value = str(value).replace("',)",'')
    value = value.strip()
    return value

def removeSpecialCharsForList(charsList):
    formattedList = []
    for item in charsList:
        formattedList.append(removeSpecialChars(item))
    formattedList = list(filter(lambda item: item.strip(), formattedList))
    return formattedList

def getFilterOptions(filterOptions):
    formattedList = removeSpecialCharsForList(filterOptions)
    formattedList = list(set(formattedList))
    return formattedList

def getCSVContent(filename):
    csvfile = Takecsv(filename)
    num_table = csvfile.row_column_num() #get the number of rows/columns for 'for loop'
    row_number = num_table[0]
    for i in range(0,row_number):
        row_list = csvfile.content_rows(i)
    return row_list

def getRegionOrSiteNameFilterOptionsForGraphingByCSV(all_site_ids, cur, colName):
    regions = []
    siteIds = (',').join(str(x) for x in all_site_ids)
    cur.execute(f'SELECT DISTINCT {colName} from site where {colName} IS NOT NULL and id in ({siteIds})')
    filterOptions = cur.fetchall()
    filterOptions = getFilterOptions(filterOptions)
    regions.extend(filterOptions)
    return regions
    
def convertJsonStringToList(jsonString):
    jsonString = str(jsonString).replace("'",'')
    return json.loads(jsonString)

def getCSVSiteIds(jsonString):
    jsonString = str(jsonString).replace("'",'')
    jsonString = jsonString.replace('\"', '')
    jsonString = jsonString.replace("[", '')
    jsonString = jsonString.replace("]", '')
    return jsonString

def getAllSpecies(siteIds, cur):
    experimentIds = []
    if len(siteIds) > 0 :
        siteIdsString = ','.join(str(x) for x in siteIds)
        cur.execute(f'SELECT Id FROM Experiment WHERE siteid in ({siteIdsString});')
        experimentIds = cur.fetchall()
        experimentIds = [j for i in experimentIds for j in i]

    allSpecies = []
    if(len(experimentIds) >0):
        experimentIdsString = ','.join(str(x) for x in experimentIds)
        cur.execute(f'select DISTINCT species from OtherInfo where species IS NOT NULL And experimentId in ({experimentIdsString});')
        allSpecies = cur.fetchall()
        allSpecies = getFilterOptions(allSpecies)
    return allSpecies

def getDatesForFilters(cur, allSiteIds, species):
    cur.execute('SELECT DISTINCT experimentid FROM otherInfo WHERE species =\'%s\';'%(species.strip()))
    allExperimentIds = cur.fetchall()
    allExperimentIds = [j for i in allExperimentIds for j in i]

    allSiteIdsString = ','.join(str(x) for x in allSiteIds)
    allExperimentIdsString = ','.join(str(x) for x in allExperimentIds)

    cur.execute('SELECT MIN(startdate) FROM Experiment WHERE siteId IN (%s) and id IN (%s);'%(allSiteIdsString, allExperimentIdsString))
    startDate = cur.fetchall()

    startDate = [j for i in startDate for j in i]
    startDate = startDate[0].strftime('%m/%d/%Y')

    cur.execute('SELECT MAX(enddate) FROM Experiment WHERE siteId IN (%s) and id IN (%s);'%(allSiteIdsString, allExperimentIdsString))
    endDate = cur.fetchall()
    endDate = [j for i in endDate for j in i]
    endDate = endDate[0].strftime('%m/%d/%Y')
    return ','.join([startDate, endDate])

def getExperimentIdsBySpecies(cur,species):
    cur.execute("SELECT experimentid FROM otherInfo WHERE species =\'%s\'" %(species.strip()))
    allExperimentIds = cur.fetchall()
    return [j for i in allExperimentIds for j in i]

def getSiteNamesByRegionAndSiteIds(cur, allSiteIds, region):
    allSiteIdsString = ','.join(str(x) for x in allSiteIds)
    cur.execute('SELECT DISTINCT siteName FROM site WHERE region =\'%s\' and id IN (%s);'%(region.strip(), allSiteIdsString))
    allSiteNames = cur.fetchall()
    allSiteNames = [j for i in allSiteNames for j in i]
    allSiteNames = [x.strip() for x in allSiteNames]
    return list(set(allSiteNames))


@app.route("/")
def home():
    return render_template("home.html")

@app.route("/data_visualisation", methods=['GET','POST'])
def dataVisualisation():
    cur = getCursor()
    cur.execute('SELECT DISTINCT region from site where region IS NOT NULL')
    regions = cur.fetchall()
    regions = getFilterOptions(regions)
    sites = []
    allSpecies = []

    if request.method == 'POST':
        cur = getCursor()
        selectedStartDate = request.form.get('startDate')
        selectedEndDate = request.form.get('endDate')
        selectedRegions = request.form.get('region')
        selectedSites= request.form.getlist('sitesCheckBoxes')
        selectedSpecies = request.form.get('species')
        
        # select aim id according to the condition the user selected
        aim_id_data = basicDataProcess(selectedStartDate, selectedEndDate, selectedRegions, selectedSites, selectedSpecies)
        list_1 = aim_id_data[0]
        experiment_list = aim_id_data[1]

        if len(experiment_list) == 0: 
            session['successs'] = True
            flash('Sorry! There is no data between %s and %s! Please try again!'% (selectedStartDate,selectedEndDate))
            return redirect(url_for('dataVisualisation' ))
        elif len(list_1) == 0: 
            session['successs'] = True
            flash('Sorry! There is no data about the species you selected!')
            return redirect(url_for('dataVisualisation' ))

        #graph process deal with - id classify
        clist = idClassify(list_1)
        #id to infodata (non-cumulative)
        detaildata = FromIdToInfo(clist)
        #generate table data
        tabledata = detaildata.generateReferenceTableData()
        #graph data process part
        graphdata = detaildata.generateGraphData()
        
        for item in graphdata:
            if len(item) == 0:
                session['successs'] = True
                flash('Sorry! there is no valid data here!')
                return redirect(url_for('dataVisualisation' ))

        # keep a non-cumulative data list for back-up  
        dlist = copy.deepcopy(graphdata)
        # generate line data part
        lineinstance = FromInfoToLinedata(dlist, selectedSpecies)
        # generate rate line data
        rateline = lineinstance.generateRateLine()
        # generate cumulative line data
        cumulativeline = lineinstance.generateCumulativeLine()
        
        return render_template("data_visualisation.html",
        sites = sites,
        regions=regions, 
        allSpecies = allSpecies,
        data_name = json.dumps(cumulativeline[0]),
        data_axis = json.dumps(cumulativeline[1]),
        rate_name = json.dumps(rateline[0]),
        rate_data = json.dumps(rateline[1]),
        rate_column = json.dumps(rateline[2]),
        db_result = tabledata[0],
        db_names = tabledata[1],
        table2_data = tabledata[2],
        table23_column = tabledata[3],
        table3_data = tabledata[4]
        )
 
    else:
        return render_template("data_visualisation.html", 
        sites = sites,
        regions=regions, 
        allSpecies = allSpecies, 
        )

@app.route("/graph_by_csv/display", methods=['GET','POST'])
def graphByCSV():
    if request.method == 'POST':
        cur = getCursor()
        selectedStartDate = request.form.get('startDate')
        selectedEndDate = request.form.get('endDate')
        region = request.form.get('region')
        selectedSites= request.form.getlist('sitesCheckBoxes')
        selectedSpecies = request.form.get('species')
        csvSiteIds = request.args.getlist('siteIds')

        allSitesString = (', '.join('\'' + item.strip() + '\'' for item in selectedSites))
        csvSiteIds = removeSpecialCharsForList(csvSiteIds)
        csvSiteIdsString = (', '.join('\'' + item.strip() + '\'' for item in csvSiteIds))

        aim_id_data = basicDataProcess_csv (allSitesString, csvSiteIdsString, selectedStartDate, selectedEndDate, region, selectedSpecies)
        list_1 = aim_id_data[0]
        experiment_list = aim_id_data[1]

        if len(experiment_list) == 0: 
            session['successs'] = True
            flash('Sorry! There is no data between %s and %s! Please try again!'% (selectedStartDate,selectedEndDate))
            return redirect(url_for('dataVisualisation' ))
        elif len(list_1) == 0: 
            session['successs'] = True
            flash('Sorry! There is no data about the species you selected!')
            return redirect(url_for('dataVisualisation' ))
       
        #graph process deal with - id classify
        clist = idClassify(list_1)
        #id to infodata (non-cumulative)
        detaildata = FromIdToInfo(clist)
        #graph data process part
        graphdata = detaildata.generateGraphData()

        for item in graphdata:
            if len(item) == 0:
                session['successs'] = True
                flash('Sorry! there is no valid data here!')
                return redirect(url_for('dataVisualisation' ))
                
        # keep a non-cumulative data list for back-up  
        dlist = copy.deepcopy(graphdata)
        # generate line data part
        lineinstance = FromInfoToLinedata(dlist, selectedSpecies)
        # generate rate line data
        rateline = lineinstance.generateRateLine()
        # generate cumulative line data
        cumulativeline = lineinstance.generateCumulativeLine()

        return render_template("graph_by_csv.html",
        data_name = json.dumps(cumulativeline[0]),
        data_axis = json.dumps(cumulativeline[1]),
        rate_name = json.dumps(rateline[0]),
        rate_data = json.dumps(rateline[1]),
        rate_column = json.dumps(rateline[2]),
        )
    else:
        return render_template("graph_by_csv.html")

@app.route("/graph_by_csv", methods=['GET','POST'])
def uploadCsvForGraphing():
    regions = []
    sites = []
    allSpecies = []
    
    if request.method == 'POST':
        filename = request.files.get('filebox')
        cur = getRealCursor()
        csv_instance = csv_upload.AgYieldsCSVToDb(filename, cur, 'reuploaded from agyields')
        column_tuples = csv_instance.check_csv()
        # checks that all expected columns are present (index 0 and 2) 
        # checks that the format is acceptable
        # returns notice to user if not
        if column_tuples[0] or column_tuples[2] or column_tuples[3]:
            return render_template("graph_by_csv.html", failedNotice = True,
                                   sites=sites,
                                   regions=regions,
                                   allSpecies=allSpecies,)
        all_site_ids = csv_instance.run_import()
        cur = getCursor()
        regions = getRegionOrSiteNameFilterOptionsForGraphingByCSV(all_site_ids, cur, 'region')
        sites = []
        allSpecies =  []

        return render_template("graph_by_csv.html",  
        sites = sites,
        regions=regions, 
        allSpecies = allSpecies, all_site_ids=all_site_ids)
    else:
        return render_template("graph_by_csv.html",  
        sites = sites,
        regions=regions, 
        allSpecies = allSpecies,)

@app.route("/csv_download", methods=['GET','POST'])
def downloadCSV():  
    cur =getCursor()      
    select_result = cur.fetchall()  
    column_names = [desc[0] for desc in cur.description]    
    return render_template("data_visualisation.html", db_result = select_result, db_names = column_names)

@app.route("/csv_upload", methods=['GET','POST'])
def uploadCSV():
    cur =getRealCursor()
    if request.method == 'POST':
        # upload to temp folder
        new_filename = request.files['filebox']
        save_filename = secure_filename(new_filename.filename)
        new_filename.save(os.path.join(app.config['UPLOAD_FOLDER'], save_filename))
        # create instance using uploaded file
        session["filename"] = f'temp/{save_filename}'
        csv_instance = csv_upload.AgYieldsCSVToDb(f'temp/{save_filename}', cur, 'new uploaded csv')
        if not csv_instance.pass_basic_check():
            os.remove(f'temp/{save_filename}')
            return redirect(url_for("cannot_upload"))
        if request.form.get('submitfile'):
            failed = csv_instance.failed_check()
            if not failed:
                minutes = csv_instance.get_minutes()
                return redirect (url_for("waiting_time", minutes=minutes))        
        return redirect(url_for("check_csv"))
    else:
        csvRequiredCols = ['Published/unpublished', 'Title', 'Author(s)', 'Journal', 'Pub Year', 'Volume', 'Pages', 'Url', 'DOI', 'Description/Notes', 'Region', 'Location Name', 'Site Name', 'Latitude', 'Longtitude', 'Altitude', 'Soil Types', 'Is it pasture/crop?', 'Is it resident/sown?', 'Sowing Date', 'Harvest Method', 'Irrigation Level', 'kgNyr', 'kgPyr', 'kgKyr', 'kgSyr', 'kgLimeyr', 'Defoliation Method', 'Dominant Species', 'Cultivar', 'Flowering Date', 'Additional Species', 'Cultivars', 'Experiment Name', 'Measurement Unit', 'What yield are you recording?', 'Data Source', 'Start Date', 'End Date', 'DM Yield', 'Grain Yield', 'Growth Rate', 'Annual Yield', 'Met Files', 'Photos', 'Soil Water Data', 'Raw Data']
        return render_template("csv_upload.html", csvRequiredCols=csvRequiredCols)

@app.route("/get_species_for_db_graphing", methods=['POST'])
def get_species_for_db_graphing(): 
    region = request.form.get('region')
    cur = getCursor()
    cur.execute('SELECT id FROM site WHERE region =\'%s\';'%(region.strip()))
    siteIds = cur.fetchall()
    siteIds = [j for i in siteIds for j in i]

    allSpecies = getAllSpecies(siteIds, cur)
    return ','.join(allSpecies)

@app.route("/get_species_for_csv_graphing", methods=['POST'])
def get_species_for_csv_graphing(): 
    region = request.form.get('region')
    csvSiteIds = request.form.get('allSiteIds')
    csvSiteIdsString = getCSVSiteIds(csvSiteIds)
    
    cur = getCursor()
    cur.execute('SELECT id FROM site WHERE region =\'%s\' and id in (%s);'%(region.strip(), csvSiteIdsString))
    siteIds = cur.fetchall()
    siteIds = [j for i in siteIds for j in i]

    allSpecies = getAllSpecies(siteIds, cur)
    return ','.join(allSpecies)

@app.route("/get_sites_for_db_graphing", methods=['GET','POST'])   
def get_sites_for_db_graphing():
    species = request.form.get('species')
    region = request.form.get('region')

    allExperimentIds = []
    allSiteIds = []
    allSiteNames = []

    cur = getCursor()
    if species :
        allExperimentIds = getExperimentIdsBySpecies(cur,species)
    if len(allExperimentIds) > 0 :
        allExperimentIdsString = ','.join(str(x) for x in allExperimentIds)
        cur.execute('SELECT DISTINCT siteId FROM Experiment WHERE id IN (%s);'%(allExperimentIdsString))
        allSiteIds = cur.fetchall()
        allSiteIds = [j for i in allSiteIds for j in i]
    if len(allSiteIds) > 0 :
        allSiteNames = getSiteNamesByRegionAndSiteIds(cur, allSiteIds, region)
    return ','.join(allSiteNames)

@app.route("/get_sites_for_csv_graphing", methods=['GET','POST'])   
def get_sites_for_csv_graphing():
    species = request.form.get('species')
    region = request.form.get('region')
    csvSiteIds = request.form.get('allSiteIds')
    csvSiteIdsString = getCSVSiteIds(csvSiteIds)

    allExperimentIds = []
    allSiteIds = []
    allSiteNames = []

    cur = getCursor()
    if species :
        allExperimentIds = getExperimentIdsBySpecies(cur,species)
    if len(allExperimentIds) > 0 :
        allExperimentIdsString = ','.join(str(x) for x in allExperimentIds)
        cur.execute('SELECT DISTINCT siteId FROM Experiment WHERE id IN (%s) and siteId in (%s);'%(allExperimentIdsString, csvSiteIdsString))
        allSiteIds = cur.fetchall()
        allSiteIds = [j for i in allSiteIds for j in i]
    if len(allSiteIds) > 0 :
        allSiteNames = getSiteNamesByRegionAndSiteIds(cur, allSiteIds, region)
    return ','.join(allSiteNames)

@app.route("/get_Dates_for_db_graphing", methods=['POST'])
def get_Dates_for_db_graphing():
    allSites = request.form.get('allSites')
    region = request.form.get('region')
    species = request.form.get('species')
    allSites = convertJsonStringToList(allSites)
    allSitesString = (', '.join('\'' + item.strip() + '\'' for item in allSites))

    cur = getCursor()
    allSiteIds = []

    cur.execute('SELECT DISTINCT id FROM site WHERE region =\'%s\' and siteName IN (%s);'%(region.strip(), allSitesString))
    allSiteIds = cur.fetchall()
    allSiteIds = [j for i in allSiteIds for j in i]

    return getDatesForFilters(cur, allSiteIds, species)

@app.route("/get_Dates_for_csv_graphing", methods=['POST'])
def get_Dates_for_csv_graphing():
    allSites = request.form.get('allSites')
    region = request.form.get('region')
    species = request.form.get('species')
    allSites = convertJsonStringToList(allSites)
    allSitesString = (', '.join('\'' + item.strip() + '\'' for item in allSites))
    csvSiteIds = request.form.get('allSiteIds')
    csvSiteIdsString = getCSVSiteIds(csvSiteIds)

    cur = getCursor()
    allSiteIds = []

    cur.execute('SELECT DISTINCT id FROM site WHERE region =\'%s\' and siteName IN (%s) and id in (%s);'%(region.strip(), allSitesString, csvSiteIdsString))
    allSiteIds = cur.fetchall()
    allSiteIds = [j for i in allSiteIds for j in i]

    return getDatesForFilters(cur, allSiteIds, species)


@app.route("/check_csv", methods=['POST', 'GET'])
def check_csv():
    cur = getRealCursor()
    filename = session['filename']
    csv_instance = csv_upload.AgYieldsCSVToDb(filename, cur, 'new uploaded csv')
    failed = False
    if request.method == 'POST':
        failed = csv_instance.failed_check()
        if not failed:
            minutes = csv_instance.get_minutes()
            return redirect(url_for("waiting_time", minutes=minutes))
    info_tuples = csv_instance.check_csv()
    extraUserCols = info_tuples[1]
    expectedCols = info_tuples[0]
    requiredCols = info_tuples[2]
    badFormatCols = info_tuples[3]
    acceptableBadFormatCols = info_tuples[4]
    numberColumns = ['dmyield', 'altitude', 'latitude', 'longitude', 'irrigationlevel',
                     'kgnyr', 'kgpyr', 'kgkyr', 'kgsyr', 'kglimeyr', 'grainyield',
                     'growthrate', 'annualyield', 'pubyear']
    return render_template("check_csv.html", fileName=filename, expectedCols=expectedCols,
                           requiredCols=requiredCols, extraUserCols=extraUserCols, badFormatCols=badFormatCols,
                           acceptableBadFormatCols=acceptableBadFormatCols, failed=failed, numberColumns=numberColumns)

@app.route("/waiting_time", methods=['POST', 'GET'])
def waiting_time():
    minutes = request.args.get("minutes")
    if request.method == 'POST':
        cur = getRealCursor()
        filename = session['filename']
        csv_instance = csv_upload.AgYieldsCSVToDb(filename, cur, 'new uploaded csv')
        # this formats the columns
        csv_instance.check_csv()
        all_site_ids = csv_instance.run_import()
        os.remove(filename)
        return render_template("post_upload.html", all_site_ids=all_site_ids)
    return render_template("waiting_time.html", minutes=minutes)

@app.route("/post_upload")
def post_upload():

    return render_template("post_upload.html")

@app.route("/cannot_upload")
def cannot_upload():
    return render_template("cannot_upload.html")
    
        




            


   

# NLT - This allows the file to be run as a standard python file (python app.py)
# helpful if you want to run the code in a development environment
if __name__ == "__main__":
    app.run()


