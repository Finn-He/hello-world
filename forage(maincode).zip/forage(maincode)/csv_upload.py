import pandas as pd
import numpy as np

class CSVtoDb():
    def __init__(self, csv_title, cur):
        self.csv_title = csv_title
        self.cur = cur
        self.csv = pd.read_csv(self.csv_title, encoding="utf-8-sig")

    # a function that is not specific to any database table
    # creates an SQL string and enters any information into the relevant database table
    # returns currentid(int) which represents the id of the row just added to database
    # takes parameters index(integer, index of the row currently being process in the csv files)
    #                   csv_row(all the data contains in the row at the index)
    #                   col_names (list, all column names in the specific table)
    #                   col_dict (dictionary, where the key is a column name and the value is the cell value of that column)
    #                   table_name (str, name of database table)
    def insert_into(self, index, csv_row, col_names, col_dict, table_name):
        for item in col_names:
            # if cell value contains data, then that data is formatted
            try:
                if not pd.isnull(self.csv.at[index, item]):
                    if str(csv_row[item]).lower() == 'not specified':
                        string_value = "null"
                    # these columns are numbers
                    elif item in ['dmyield', 'altitude', 'latitude', 'longitude', 'irrigationlevel',
                                 'kgnyr', 'kgpyr', 'kgkyr', 'kgsyr', 'kglimeyr', 'grainyield',
                                 'growthrate', 'annualyield', 'pubyear', 'trialduration',
                                 'hasmetfiles', 'hasphotos', 'hassoilwaterdata', 'hasrawdata']:                                 
                        string_value = str(csv_row[item])
                    # if date input is in format DD/MM/YYYY
                    # must be reordered to YYYY-MM-DD
                    elif item in ['startdate', 'enddate', 'floweringdate', 'sowingdate']:
                        if csv_row[item].count('/00') or csv_row[item].count('-00'):
                            string_value = "null"
                        elif csv_row[item].count("/") > 0:
                            value = csv_row[item].split("/")
                            reorder = [value[2], value[1], value[0]]
                            string_value = "'" + "-".join(reorder) + "'"
                        else:
                            string_value = "'" + str(csv_row[item]) + "'"
                    # quotes added for final sql statement to be interpreted as string
                    else:
                        string_value = "'" + str(csv_row[item]) + "'"
                    col_dict.update({item: string_value})
            except KeyError:
                print('key error')
        # formatting for sql statement
        col_names = ', '.join('%s' % k for k in col_dict.keys())
        col_values = ', '.join(v for v in col_dict.values())
        check = ' and '.join('{}={}'.format(key, value)
                            for key, value in col_dict.items())
        # check statement looks for a row in the database that contains identical information to the csv row being processed
        check_statement = (f"select * from {table_name} where {check};")
        self.cur.execute(check_statement)
        preexisting = self.cur.fetchall()
        # if that row already exists, gets the id of the row for use in the next table
        if preexisting:
            currentid = preexisting[0]['id']
        else:
            # sql_statement inserts a row into the database contains all the information in the csv row
            sql_statement = (
                f"insert into {table_name} ({col_names}) values ({col_values}) returning id;")
            self.cur.execute(sql_statement)
            currentid = self.cur.fetchone()['id']
        return currentid

class AgYieldsCSVToDb(CSVtoDb):
    def __init__ (self, csv_title, cur, upload_type):
        self.upload_type = f"'{upload_type}'" 
        super().__init__(csv_title, cur)        

    # checks which columns are present or missing
    # reformats whichever columns it can to expected titles
    # checks the format of data in the columns
    # returns tuples with information about all these checks
    def check_csv(self):
        expected_columns = ['Published/unpublished', 'Title', 'Author(s)', 'Journal', 'Pub Year', 'Volume', 'Pages', 'Url', 'DOI', 'Description/Notes', 'Location Name', 'Latitude', 'Longtitude', 'Altitude', 'Soil Types', 'Is it pasture/crop?', 'Is it resident/sown?', 'Sowing Date', 'Harvest Method', 'Irrigation Level', 'kgNyr', 'kgPyr', 'kgKyr',
                           'kgSyr', 'kgLimeyr', 'Defoliation Method', 'Cultivar', 'Flowering Date', 'Additional Species', 'Cultivars', 'Data Source', 'Grain Yield', 'Growth Rate', 'Annual Yield', 'Met Files', 'Photos', 'Soil Water Data', 'Raw Data']
        remaining_expected_columns = [x.lower().strip().replace(' ', '') for x in expected_columns]
        # format items in list to match below
        self.csv.columns = self.csv.columns.str.lower().str.strip()
        self.csv.columns = self.csv.columns.str.replace(' ', '')
        user_columns = self.csv.columns.values.tolist()
        final_user_columns = user_columns.copy()
        missing_required_columns = ['experimentname', 'sitename', 'region', 'startdate', 'enddate', 'dmyield',
                            'measurementunit', 'whatyieldareyourecording?', 'dominantspecies']
        post_rename_columns = {'pasturecrop': 'isitpasture/crop?', 'yieldtype': 'whatyieldareyourecording?', 'residentsown': 'isitresident/sown?', 'location': 'locationname', 'species': 'dominantspecies', 'otherspecies': 'additionalspecies', 'othercultivar': 'cultivars',
                               'hasmetfiles': 'metfiles', 'hasphotos': 'photos', 'hassoilwaterdata': 'soilwaterdata', 'hasrawdata': 'rawdata', 'description': 'description/notes', 'author': 'author(s)', 'longitude': 'longtitude', 'published': 'published/unpublished'}
        # go through all user columns
        # if in the required columns, expected, or the post_rename, remove

        # check all the expected columns
        # if they are in the uploaded csv, remove them from lists that will be returned
        for name in user_columns:
            if name in remaining_expected_columns:
                remaining_expected_columns.remove(name)
            elif name in missing_required_columns:
                missing_required_columns.remove(name)
            elif name in post_rename_columns:
                if post_rename_columns[name] in missing_required_columns:
                    missing_required_columns.remove(post_rename_columns[name])
                else:
                    remaining_expected_columns.remove(post_rename_columns[name])
            else:
                continue
            final_user_columns.remove(name)
        # returns five lists: 
        # remaining_expected_columns are columns in database but not in user csv
        # user_columns are columns in user csv that will be ignored during import
        # missing_required_columns
        # columns with formatting that will cause import to fail
        # columns with wrong formatting that will not causeimport to fail
        self.format_csv()
        incorrect_formats = self.incorrect_formats()
        passable_incorrect_formats = self.passable_incorrect_formats()
        return (remaining_expected_columns, final_user_columns, missing_required_columns, incorrect_formats, 
                passable_incorrect_formats)
    
    # checks for formats within columns that will not break the import but may cause user to lose some information
    def passable_incorrect_formats(self):
        incorrect_formats = []
        try:
            # published column should contain either the word 'published' or 'unpublished'
            extra_published_rows = self.word_in_column('published', 'published', 'unpublished')
            if extra_published_rows > 0:
                incorrect_formats.append('published')
            extra_pasture_rows = self.word_in_column('pasturecrop', 'pasture', 'crop')
            if extra_pasture_rows > 0:
                incorrect_formats.append('pasturecrop')
            extra_resident_rows = self.word_in_column('residentsown', 'resident', 'sown')
            if extra_resident_rows > 0:
                incorrect_formats.append('residentsown')
        except KeyError:
            pass
        return incorrect_formats

    # checks for null values in columns (useful for columns that must have values, like species)
    def nulls_in_column(self, column_name):
        nanvals = self.csv[column_name].isnull().sum()
        if nanvals > 0:
            return True
        else:
            return False

    # checks for two words in a column (useful for columns that only accept two words, like resident-sown)
    # will return > 0 if there are nonnull values in the column that don't contain those words
    def word_in_column(self, column_name, word1, word2):
        nanvals = self.csv[column_name].isnull().sum()
        # early exit if all values null
        if nanvals == len(self.csv):
            return 0
        self.csv[column_name] = self.csv[column_name].str.lower()
        length1 = self.csv[column_name].str.contains(word1).sum()
        length2 = self.csv[column_name].str.contains(word2).sum()
        extra_rows = len(self.csv) - \
            (length1 + length2 + nanvals)
        return extra_rows

    # checks for formats within columns that cannot be allowed to be uploaded
    def incorrect_formats(self):
        incorrect_formats = []
        number_columns = ['dmyield', 'altitude', 'latitude', 'longitude', 'irrigationlevel', 
                        'kgnyr', 'kgpyr', 'kgkyr', 'kgsyr', 'kglimeyr', 'grainyield', 
                        'growthrate', 'annualyield', 'pubyear']
        for name in number_columns:
            try:
                if self.csv[name].dtypes == 'float64' or self.csv[name].dtypes == 'int64':
                    pass
                else:
                    incorrect_formats.append(name)
            except KeyError:
                pass
        for name in ['hasmetfiles', 'hasphotos', 'hassoilwaterdata', 'hasrawdata']:
            try:
                extra_rows = self.word_in_column(name, 'true', 'false')
                if extra_rows > 0:
                    incorrect_formats.append(name)
            except KeyError:
                print('key error')
        try:
            regions = len(self.csv.loc[self.csv['region'].isin(
                ['Northland', 'Auckland', 'Waikato', 'Bay of Plenty', 'Gisborne', "Hawke's Bay", 
                'Taranaki', 'Whanganui-Manawatu', 'Wellington', 'Tasman', 'Nelson', 'Marlborough', 'West Coast',
                'Canterbury', 'Otago', 'Southland'])])
            if regions != len(self.csv):
                incorrect_formats.append('regions')
        except KeyError:
            print('yuppo region')
        for name in ['startdate', 'enddate', 'sowingdate', 'floweringdate']:
            try:
                extra_rows = self.word_in_column(name, 
                                                 '(0?[1-9]|1[0-2])[-\\/ ]?(0?[1-9]|[12][0-9]|3[01])[-/ ]?(?:19|20)[0-9]{2}',
                                                 '(?:19|20)[0-9]{2}[-\\/ ]?(0?[1-9]|1[0-2])[-/ ]?(0?[1-9]|[12][0-9]|3[01])')
                if extra_rows > 0:
                    incorrect_formats.append(name)
            except KeyError:
                print('key error data')
        # will be empty(false) if all formats are okay
        for name in ['startdate', 'enddate', 'sitename', 'species', 'region']:
            try:
                if self.nulls_in_column(name):
                    problem = name + "null"
                    incorrect_formats.append(problem)
            except KeyError:
                print('key error data')
        return incorrect_formats

    # a function running the bare minimum tests to see if a file can safely be uploaded
    def failed_check(self):
        check_tuple = self.check_csv()
        # if missing_required_columns has elements in it, cannot upload, has failed
        if len(check_tuple[2]) > 0:
            return True
        if self.incorrect_formats():
            return True
        return False

    # approx how long it will take to upload a file
    def get_minutes(self):
        rows = len(self.csv)
        rows_per_min = 60
        mins = int(rows/rows_per_min)
        return str(mins)

    #rename and format column names to match datbase
    def format_csv(self):
        columns_dict = {'isitpasture/crop?': 'pasturecrop', 'whatyieldareyourecording?': 'yieldtype',
                        'isitresident/sown?': 'residentsown', 'locationname': 'location',
                        'dominantspecies': 'species', 'additionalspecies': 'otherspecies',
                        'cultivars': 'othercultivar', 'metfiles': 'hasmetfiles', 'photos': 'hasphotos',
                        'soilwaterdata': 'hassoilwaterdata', 'rawdata': 'hasrawdata',
                        'description/notes': 'description', 'author(s)': 'author', 'longtitude': 'longitude',
                        'published/unpublished':'published'}
        self.csv = self.csv.rename(columns=columns_dict)
        self.csv.columns = self.csv.columns.str.lower().str.strip()
        self.csv.columns = self.csv.columns.str.replace(' ', '')

    # iterates through each row of the csv file
    # creates a list of columns in the csv associated with one table in the database
    # runs the insert_into function for those columns which inputs that info into the database
    # all csvs imported this way will be distinguised with 'AGYieldsCSV' in the 'otherinfo' column
    def run_import(self):
        all_site_ids = []
        for i, row in self.csv.iterrows():
            print(i)
            # study table
            study_columns = {}
            try:
                if pd.isnull(self.csv.at[i, 'published']):
                    pass
                elif row['published'].count('published'):
                    published = 'True'
                    study_columns.update({'published': published})
                elif row['published'].count('unpublished'):
                    published = 'False'
                    study_columns.update({'published': published})
                else:
                    pass
            except KeyError:
                pass
            study_col_names = ['title', 'author', 'journal', 'pubyear', 'volume', 'pages', 'url', 'doi', 'description']
            studyid = self.insert_into(i, row, study_col_names, study_columns, 'study')

            # site table
            site_columns = {'studyid': str(studyid)}
            site_col_names = ['sitename', 'location', 'region', 'latitude', 'longitude', 'altitude',
                             'hasmetfiles', 'hasphotos', 'hassoilwaterdata', 'hasrawdata']
            siteid = self.insert_into(i, row, site_col_names, site_columns, 'site')
            if siteid not in all_site_ids:
                all_site_ids.append(siteid)

            # experiment table
            experiment_columns = {'siteid':str(siteid)}
            experiment_col_names = ['experimentname', 'startdate', 'enddate', 'dmyield', 'measurementunit', 
                                    'yieldtype', 'datasource', 'grainyield', 'annualyield', 'growthrate']
            experimentid = self.insert_into(i, row, experiment_col_names, experiment_columns, 'experiment')                        

            # otherinfo table
            other_columns = {'experimentid':str(experimentid), 'otherinfo':self.upload_type}
            try:
                # residentsown column
                if pd.isnull(self.csv.at[i, 'residentsown']):
                    pass
                elif row['residentsown'].count('resident'):
                    residentsown = "'Resident'"
                    study_columns.update({'residentsown': residentsown})
                elif row['residentsown'].count('sown'):
                    residentsown = "'Sown'"
                    study_columns.update({'residentsown': residentsown})
                else:
                    pass
                #pasturecrop column
                if pd.isnull(self.csv.at[i, 'pasturecrop']):
                    pass
                elif row['pasturecrop'].count('pasture'):
                    pasturecrop = "'Pasture'"
                    study_columns.update({'pasturecrop': pasturecrop})
                elif row['pasturecrop'].count('crop'):
                    pasturecrop = "'Crop'"
                    study_columns.update({'pasturecrop': pasturecrop})
                else:
                    pass
            except KeyError:
                pass
            other_col_names = ['species', 'cultivar', 'otherspecies', 'othercultivar', 'floweringdate',
                                'irrigationlevel', 'kgpyr', 'kgnyr', 'kglimeyr', 'kgsyr', 'kgkyr',
                                'defoliationmethod', 'harvestmethod', 'soiltypes', 'sowingdate']
            otherid = self.insert_into(i, row, other_col_names, other_columns, 'otherinfo')
        return all_site_ids                        

    # a check run to see if at least one column name matches the expected column names
    # used as a safety check before saving the file to the Temp folder
    def pass_basic_check(self):
        expected_columns = ['Published/unpublished', 'Title', 'Author(s)', 'Journal', 'Pub Year', 'Volume', 'Pages', 'Url', 'DOI', 'Description/Notes', 'Location Name', 'Latitude', 'Longtitude', 'Altitude', 'Soil Types', 'Is it pasture/crop?', 'Is it resident/sown?', 'Sowing Date', 'Harvest Method', 'Irrigation Level', 'kgNyr', 'kgPyr', 'kgKyr',
                           'kgSyr', 'kgLimeyr', 'Defoliation Method', 'Cultivar', 'Flowering Date', 'Additional Species', 'Cultivars', 'Data Source', 'Grain Yield', 'Growth Rate', 'Annual Yield', 'Met Files', 'Photos', 'Soil Water Data', 'Raw Data']
        remaining_expected_columns = [x.lower().strip().replace(' ', '') for x in expected_columns]
        # format items in list to match below
        self.csv.columns = self.csv.columns.str.lower().str.strip()
        self.csv.columns = self.csv.columns.str.replace(' ', '')
        user_columns = self.csv.columns.values.tolist()
        final_user_columns = user_columns.copy()
        missing_required_columns = ['experimentname', 'sitename', 'region', 'startdate', 'enddate', 'dmyield',
                            'measurementunit', 'whatyieldareyourecording?', 'dominantspecies']
        # go through all user columns
        # if in the required columns, expected, or the post_rename, remove

        # check all the expected columns
        # if they are in the uploaded csv, remove them from lists that will be returned
        for name in user_columns:
            if name in remaining_expected_columns:
                pass
            elif name in missing_required_columns:
                pass
            else:
                continue
            final_user_columns.remove(name)
        # there is no recognizeable column
        if len(final_user_columns) == len(user_columns):
            return False
        else:
            return True

class CarmensCSV(CSVtoDb):
    def __init__(self, csv_title, cur):
        super().__init__(csv_title, cur)

    def format_csv(self):
        columns_translation_dict = {"ID": "experimentname", 'RawDMYData': 'hasrawdata',
                                    'MetData': 'hasmetfiles', 'SoilProperties': 'hassoilwaterdata',
                                    'Vol': 'volume', 'SoilType': 'soiltypes', 'Irrigated': 'irrigationlevel',
                                    'YieldDataSource': 'datasource', 'MeasurementStartDate': 'startdate',
                                    'MeasurementEndDate': 'enddate', 'YieldComposition': 'yieldtype',
                                    'OtherInformation': 'otherinfo', 'MixSpec': 'otherspecies'}
        self.csv = self.csv.rename(columns=columns_translation_dict)
        self.csv.columns = self.csv.columns.str.lower().str.strip()

    def run_import(self):
        #not used are PastureType and DataStructure and TrialDuration
        #not contained here but in AGYields csv= ['hasphotos', 'url', 'doi', 'description',
        # 'othercultivar', 'floweringdate', 'grainyield', 'annualyield', 'growthrate' ]
        for i, row in self.csv.iterrows():
            print(i)
            #study table
            if row['datatype'] == 'Paper':
                published = 'True'
            else:
                published = 'False'
            study_columns = {'published':published}
            study_col_names = ['title', 'author', 'journal', 'pubyear', 'volume', 'pages']
            studyid = self.insert_into(i, row, study_col_names, study_columns, 'study')

            # site table
            site_columns = {'studyid': str(studyid)}
            for item in ['hasmetfiles', 'hassoilwaterdata', 'hasrawdata']:
                if pd.isnull(row[item]):
                    pass
                elif row[item] == 'Yes':
                    site_columns[item] = 'True'
                elif row[item] == 'No':
                    site_columns[item] = 'False'
            site_col_names = ['sitename', 'region', 'latitude', 'longitude', 'altitude']
            siteid = self.insert_into(i, row, site_col_names, site_columns, 'site')

            # experiment table
            # experiment_name is using original 'id' field, so likely to be an integer, must be treated as string
            experiment_name = "'" + str(row['experimentname']) + "'"
            experiment_columns = {'siteid': str(siteid), 'measurementunit':"'kg/ha'", 'experimentname':experiment_name}
            experiment_col_names = ['trialduration', 'startdate', 'enddate', 'yieldtype', 'datasource', 'dmyield']
            experimentid = self.insert_into(i, row, experiment_col_names, experiment_columns, 'experiment')

            # otherinfo table
            other_columns = {'experimentid': str(experimentid)}
            # defoliation method must be concatenated with defoliation details if they are not null
            if pd.isnull(row['defoliation']) and pd.isnull(row['defoliationdetails']):
                pass
            else:
                defoliation_method = "'"
                if not pd.isnull(row['defoliation']):
                    defoliation_method += row['defoliation']
                    defoliation_method += ': '
                if not pd.isnull(row['defoliationdetails']):
                    defoliation_method += row['defoliationdetails']
                defoliation_method += "'"
                other_columns['defoliationmethod'] = defoliation_method
            # forage type must be filtered to determine if it is pasture or crop, if it contains data
            if not pd.isnull(row['foragetype']):
                if row['foragetype'].count('Pasture') > 0:
                    other_columns['pasturecrop'] = "'Pasture'"
                else: 
                    other_columns['pasturecrop'] = "'Crop'"            
            other_col_names = ['species', 'cultivar', 'otherspecies', 
                            'irrigationlevel', 'kgpyr', 'kgnyr', 'kglimeyr', 'kgsyr', 'kgkyr',
                            'harvestmethod', 'soiltypes', 'otherinfo',
                            'rainfedirrigated', 'residentsown', 'sowingdate']
            otherid = self.insert_into(i, row, other_col_names, other_columns, 'otherinfo')
                            
