import psycopg2, db_details
import copy
import operator
from flask import Flask,url_for,session, redirect, flash
from collections import defaultdict
from dateprcess_package import datedoublelist


dbconn = None
def getCursor():
    global dbconn
    if dbconn == None:
        conn = psycopg2.connect(dbname=db_details.dbname, user=db_details.dbuser, password=db_details.dbpass, host=db_details.dbhost, port=db_details.dbport)
        conn.autocommit = True
        dbconn = conn.cursor()
        return dbconn
    else:
        return dbconn

class FromIdToInfo():
    def __init__(self, nestedlist):
        self.nestedlist = nestedlist

    def generateReferenceTableData(self):
        cur = getCursor()
        table_list = []
        table_column = []
        data_t2 = []
        for j in range(0,len(self.nestedlist)):
            for i in range(0,len(self.nestedlist[j])):
                #for table data
                sql_y ='SELECT \'line%s\' as linename, experiment.experimentname, experiment.startdate, experiment.enddate, COALESCE(experiment.dmyield, 0) as dmyield, experiment.siteid,\
                        experiment.yieldtype,experiment.datasource,experiment.grainyield,experiment.growthrate, \
                        otherinfo.experimentid,otherinfo.species,otherinfo.cultivar,otherinfo.floweringdate,otherinfo.otherspecies,\
                        otherinfo.othercultivar,otherinfo.rainfedirrigated,otherinfo.irrigationlevel,otherinfo.kgpyr,otherinfo.kgnyr,\
                        otherinfo.kgkyr,otherinfo.kgsyr,otherinfo.kglimeyr,otherinfo.defoliationmethod,otherinfo.harvestmethod,\
                        otherinfo.soiltypes,otherinfo.pasturecrop,otherinfo.residentsown,otherinfo.sowingdate,otherinfo.otherinfo \
                        FROM experiment INNER JOIN otherinfo ON experiment.id=otherinfo.experimentid WHERE experiment.id=%s;'%(j, self.nestedlist[j][i],)
                cur.execute(sql_y)
                table_data= cur.fetchone()
                table_list.append(table_data)  #table1 data
                table_column = [desc[0] for desc in cur.description]  #table1 column
                table_data_lv = list(table_data)
                data_t2.append(table_data_lv)

        
        # table2 and table3 data
        column_t2 = []
        for item in table_column:
            column_t2.append(item)
        
        del column_t2[1:11]

        data_t3 = []
        for item_st in data_t2:
            data_t3_unit = []
            data_t3_unit.append(item_st[0])
            data_t3_unit.append(item_st.pop(2))
            data_t3_unit.append(item_st.pop(2))
            data_t3_unit.append(item_st.pop(2))
            data_t3.append(data_t3_unit)
            del item_st[1:8]

        tb2_list = []
        [tb2_list.append(y) for y in data_t2 if not y in tb2_list]  # remove duplicates
        
        unitlength = len(tb2_list[0])
        biglist_t2 = []
        
        for i in range(1,unitlength):
            list_t2te = []
            list_t2te.append(column_t2[i])
            for item_e in tb2_list:
                list_t2te.append(item_e[i])
            biglist_t2.append(list_t2te)    #the data can be used in table2

        columnname_t2 = ['linename']
        for item_e in tb2_list:
            columnname_t2.append(item_e[0])  #the column can be used in table2

        # this is for non-cumulative data for table3
            # (1)-reclassify the data according to the linename - data_t3[j][0]/index_d3[i]
        index_d3 = []
        for j in range(1, len(columnname_t2)):
              index_d3.append(columnname_t2[j])
        
        data_t3_duration = []
        for i in range(0,len(index_d3)):
            temporary_series = []
            for j in range(0,len(data_t3)):
                temporary_unit = []
                if data_t3[j][0] == index_d3[i]:
                    temporary_unit.append(data_t3[j][1])
                    temporary_unit.append(data_t3[j][2])
                    temporary_unit.append(data_t3[j][3])
                    temporary_series.append(temporary_unit)
            data_t3_duration.append(temporary_series)
        
        for x in range(0,len(data_t3_duration)):
            temporary_remove = []
            [temporary_remove.append(y) for y in data_t3_duration[x] if not y in temporary_remove]  # remove duplicates
            data_t3_duration[x] = temporary_remove

        for itemd3_s in data_t3_duration:
            itemd3_s.sort(key=operator.itemgetter(0))   # ,reversed = true means: Descending  #resort according the 0 position key.

            # (2)-convert the format of data and make it become ['yyyy-mm-dd to yyyy-mm-dd', xxxxx]
        for i in range(0,len(data_t3_duration)):
            for j in range(0,len(data_t3_duration[i])):
                item_u_te = []
                item_u_te.append(str(data_t3_duration[i][j][0]) + ' to ' + str(data_t3_duration[i][j][1]))
                item_u_te.append(float(data_t3_duration[i][j][2]))
                data_t3_duration[i][j] = item_u_te

            # generate a same list with data_t3_duration for later use, prevent the number from being deleted in the next step.
        backup_t3data=copy.deepcopy(data_t3_duration)

            # (3)-try to get a unique duration list from original data
        data_t3_duration1 = [j for i in data_t3_duration for j in i]
        for item_tem in data_t3_duration1:
            del item_tem[1]

        temporary_remove1 = []
        [temporary_remove1.append(y) for y in data_t3_duration1 if not y in temporary_remove1]  # remove duplicates
        
        fisrtd3_data = [j for i in temporary_remove1 for j in i]
        fisrtd3_data = sorted(fisrtd3_data)   # ,reversed = true means: Descending  #resort according the 0 position key.

            # (4)- generate the data list for table3
        first_t3 = []      
        for item1 in fisrtd3_data:
            first_t3.append([item1])   #this is the first column data

            # (5) -Fill in the position with no number as null in advance
        for item_x in first_t3:
            flag_dura = 1 
            while flag_dura < len(columnname_t2):  # use 'columnname_t2' to get the number of 'null' we should have
                item_x.append('null')
                flag_dura += 1

            # (6) - make the data(data_t3_duration) of each duration become the style like [[duration1, line0data,line1data, line2data...],[duration2, line0data,line1data, line2data...]...]
        
        flag_t4 = 0                   
        while flag_t4 < len(fisrtd3_data):
            for r in range(0,len(backup_t3data)):
                for item_u in backup_t3data[r]:
                    if first_t3[flag_t4][0] == item_u[0]:
                        first_t3[flag_t4][r+1] = item_u[1]        # to here, first_t3 can be used in table3 for data(non-cumulative), it is not the corresponding cumulative data
            flag_t4 += 1 
        
        return table_list, table_column, biglist_t2, columnname_t2, first_t3

    def generateGraphData(self):
        cur = getCursor()
        # this for Cumulative line graph
        for item in self.nestedlist:
            for i in range(0,len(item)):
                # for graph data
                sql_x = 'SELECT to_char(startdate, \'yyyy-mm-dd\'), to_char(enddate, \'yyyy-mm-dd\'),\'\'||COALESCE(experiment.dmyield, 0) as dmyield FROM experiment WHERE id = %s;'%(item[i],)
                cur.execute(sql_x)
                data_select= cur.fetchone()
                data_unit = list(data_select)
                item[i] = data_unit


        # find the average of multiple small areas in a common of land(has same startdate and end date)
        for i in range(0,len(self.nestedlist)):
            temporarylist = []
            mydict = defaultdict(list)
            for sta, end, value in self.nestedlist[i]:    # here :  sta, end, value.  these three items represent the three element of each small unit list respectively. And they together represent the small unit list object.
                mydict[(sta,end)].append(float(value))
            for (sta, end), values in mydict.items():
                temporarylist.append([sta, end, sum(values)/len(values)])
            self.nestedlist[i] = temporarylist

        # sort the unit according to the value of first data in unit 
        for item_s in self.nestedlist:
            item_s.sort(key=operator.itemgetter(1))   # ,reversed = true means: Descending 
      
        clist = [[item_u for item_u in item_s if len(datedoublelist(item_u[0],item_u[1])) != 0] for item_s in self.nestedlist]     #! delete the error data which is casued by original csv file. error: the start date is same with the end date
        clist = [[item_u for item_u in item_s if (item_u[0] != item_s[0][0] or item_u[1] != item_s[-1][1])] for item_s in clist]  #! delete the error data which is casued by original csv file. error: the cumulative data in the original file.

        # make the value of first day 0, and generate a data list, line name list and for using.
        for m in range(0,len(clist)):
            if len(clist[m]) != 0:
                clist[m].insert(0,[clist[m][0][0],clist[m][0][0],0])
                for n in range(len(clist[m])):
                    del clist[m][n][0]
        return clist
            
        
        