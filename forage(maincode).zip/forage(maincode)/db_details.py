dbuser = "postgres"
dbpass = "Scrumteam1" #"PUT YOUR PASSWORD HERE"
dbhost = "forage.cha2cfsuyw5p.us-east-1.rds.amazonaws.com" #"PUT YOUR AWS Connect String here"
dbport = "5432"
dbname = "fullsimplified"

#dbname = "forage"


