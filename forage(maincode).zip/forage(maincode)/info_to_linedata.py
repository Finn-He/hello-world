from dateprcess_package import datedoublelist
import operator
from collections import defaultdict
import copy
from dateprcess_package import datelist, datedoublelist, durationdays, datedoublelist_2

class FromInfoToLinedata():
    def __init__(self, infolist, species):
        self.infolist = infolist
        self.species = species

    def generateRateLine(self):
        for i in range(0,len(self.infolist)):
            for item_u in self.infolist[i]:
                item_u.append('line' + str(i))

        hlist = []
        for i in range(0,len(self.infolist)):
            tem_series = []
            for j in range(1,len(self.infolist[i])):
                new_te = datedoublelist(self.infolist[i][j-1][0],self.infolist[i][j][0])   # datedoublelist will lack of the last one date element for avoiding the multiple duplicate same date element.
                rate = self.infolist[i][j][1] / len(new_te)
                for item in new_te:    # new_te
                    item.append(rate)
                    item.append(self.infolist[i][j][2])       # re-mark linex
                tem_series.append(new_te)      # replace the original unit      # new_te
            tem_1 = [j for i in tem_series for j in i]
            hlist.append(tem_1)
    

        ratelinename = []
        for i in range(0,len(hlist)):
            ratelinename.append(hlist[i][0][2])   # to here, ratelinename can be used for rate chart name part.
            for j in range(0,len(hlist[i])):
                hlist[i][j][0] = hlist[i][j][0][5:]
                del hlist[i][j][2]                 
        ratelinename.append('averageline-%s'%(self.species,)) #,selectedRegions,selectedSites,
        
        # find the average of multiple object which has different vlue but same mm-dd 
        for i in range(0,len(hlist)):
            temporarylist1 = []
            mydict1 = defaultdict(list)
            for datepoint,value in hlist[i]:    # here :  date, value.  these three items represent the two element of each small unit list respectively. And they together represent the small unit list object.
                mydict1[(datepoint)].append(float(value))
            for (datepoint), values in mydict1.items():
                temporarylist1.append([datepoint, sum(values)/len(values)])
            hlist[i] = temporarylist1


        hlist_tem = copy.deepcopy(hlist)
        hlist_average = [j for i in hlist_tem for j in i]

        average_series = []
        mydict2 = defaultdict(list)
        for date_average,value in hlist_average:    # here :  date, value.  these three items represent the three element of each small unit list respectively. And they together represent the small unit list object.
            mydict2[(date_average)].append(float(value))
        for (date_average), values in mydict2.items():
            average_series.append([date_average, sum(values)/len(values)])

        hlist.append(average_series)      # to here, hlist can be used for the rate graph data
        # generate a column list for rate chart
        for item_s in hlist:
            item_s.sort(key=operator.itemgetter(0))
        
        column_te = []
        for item_s in hlist:
            for item_u in item_s:
                column_te.append(item_u[0])
        
        column_rate = []
        [column_rate.append(y) for y in column_te if not y in column_rate]
        column_rate = sorted(column_rate)       # to here, column_rate can be used for the rate graph column

        return ratelinename, hlist, column_rate

    def generateCumulativeLine(self):
        for i in range(0,len(self.infolist)):
            for item_u in self.infolist[i]:
                item_u.append('line' + str(i))
        
        # Product Owner hope we just show one year date as x-Axis and use 07-01 as the begin of one year, and the value of 07-01 should be 0 if there be value.This part is for this function
        for i in range(0,len(self.infolist)):
            j = 1
            while j < len(self.infolist[i]):
                sixthritylist_1 = datelist(self.infolist[i][j-1][0],self.infolist[i][j][0])
                if len(sixthritylist_1) != 0:
                    sixthrity = sixthritylist_1[0][:4]+'-06-30'
                    sevenfirst = sixthritylist_1[0][:4]+'-07-01'
                    value_after0630 = (self.infolist[i][j][1]/durationdays(self.infolist[i][j-1][0],self.infolist[i][j][0])) * durationdays(sixthrity,self.infolist[i][j][0])
                    value_before0630 = (self.infolist[i][j][1]/durationdays(self.infolist[i][j-1][0],self.infolist[i][j][0])) * durationdays(self.infolist[i][j-1][0],sixthrity)
                    self.infolist[i][j][1] = value_after0630
                    self.infolist[i].insert(j,[sevenfirst, 0, self.infolist[i][j-1][2]])
                    self.infolist[i].insert(j,[sixthrity, value_before0630, self.infolist[i][j-1][2]])
                    j = j + 3
                else:
                    j += 1  

        #reclassify the series according to the product owner's requirement.
        flist = []
        for i in range(0,len(self.infolist)):
            j = 1
            tem = []
            while j < len(self.infolist[i]):
                sixthritylist_1 = datelist(self.infolist[i][j-1][0],self.infolist[i][j][0])
                if j == (len(self.infolist[i]) - 1):
                    if len(sixthritylist_1) != 0:
                        sevenfirst = sixthritylist_1[0][:4]+'-07-01'
                        if len(tem) == 0 :
                            reunit = self.infolist[i].pop(j)
                            tem.append(reunit)
                            flist.append(tem)
                            tem = []
                        else:
                            reunit = self.infolist[i].pop(j)
                            tem.append(reunit)
                            flist.append(tem)       
                            tem = []
                    else:
                        j += 1  
                else:
                    sixthritylist_2 = datelist(self.infolist[i][j][0],self.infolist[i][j+1][0])
                    if len(sixthritylist_1) != 0 and len(sixthritylist_2) == 0:
                        sevenfirst = sixthritylist_1[0][:4]+'-07-01'
                        if len(tem) == 0:
                            reunit = self.infolist[i].pop(j)
                            tem.append(reunit)
                        else:
                            reunit = self.infolist[i].pop(j)
                            tem.append(reunit)
                    elif len(sixthritylist_1) != 0 and len(sixthritylist_2) != 0:
                        if len(tem) == 0:
                            reunit = self.infolist[i].pop(j)
                            tem.append(reunit)
                            flist.append(tem)
                            tem = []
                        else:
                            reunit = self.infolist[i].pop(j)
                            tem.append(reunit)
                            flist.append(tem)
                            tem = []
                    else:
                        j += 1

        for item_s in self.infolist:
            flist.append(item_s)

        for item_s in flist:
            item_s.sort(key=operator.itemgetter(0))

        glist = copy.deepcopy(flist)
        linename = []
        for item_s in glist:
           nameunit = item_s[0][2] + ' (' + item_s[0][0] +  ' to ' + item_s[-1][0] + ')'
           linename.append(nameunit)         # to here, 'linename' can be used to generate json file for cumulative line

        # generate final available data(without year and linename) 
        for item_s in flist:
            for item_u in item_s:
                item_u[0] = item_u[0][5:]
                del item_u[2]            #  non-cumulative.
        
        a_1 = 0 
        for item_s in flist:
            for j in range(0,len(item_s)):
                item_s[j][1] = a_1
                if j < len(item_s) - 1:
                    a_1 = a_1 + float(item_s[j+1][1])      
            a_1 = 0                                # to here, 'flist' can be used to generate json file for  cumulative line

        return linename, flist