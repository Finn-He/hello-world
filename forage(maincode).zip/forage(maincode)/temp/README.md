# temp file
this folder is used to temporarily store csv files so user can navigate site and have access to their upload.