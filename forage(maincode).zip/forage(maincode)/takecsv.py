import pandas as pd

class Takecsv():
    def __init__(self, file):
        self.file = file
        self.df = pd.read_csv(self.file)  # ,header=0/None/1

    # get the number of rows and columns
    def row_column_num(self):
        row_num = int(self.df.index.stop) # it just return the number of main body rows, not include the columns row
        column_num = len(self.df.columns)
        return row_num,column_num

    # get column headings
    def get_col_list(self, file):
        col_list  = pd.read_csv(file, index_col=0, nrows=0).columns.tolist()
        return col_list

    # get the cotent of one column in all rows, colNames is an array of column headings
    def get_content_by_col_name(file, colNames):
        df = pd.read_csv(file, skipinitialspace=True, usecols=colNames)
        return df[colNames]

    # get the cotent of one row
    def content_rows(self,rownum):
        content_row = self.df.loc[rownum]
        row_list = content_row.values
        return row_list
    
    # get the cotent of one column
    def content_cols(self,colnum):
        content_col = self.df.iloc[:,colnum]
        col_list = content_col.values
        return col_list

    # get the content of one cell
    def content_cell(self,row_cell,col_cell):
        cellvalue = self.df.iloc[[row_cell],[col_cell]]
        return cellvalue