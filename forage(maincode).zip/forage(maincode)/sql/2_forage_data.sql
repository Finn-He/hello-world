--
-- PostgreSQL database dump
--

-- Dumped from database version 12.5


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: soil_type; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.soil_type VALUES (1, 'Ahaura Stony Silt Loam', 'Acidic Mafic Brown Soil', 'Typic Haplorthod', '2021-04-08 13:11:17.332685');
INSERT INTO public.soil_type VALUES (2, 'Taupo Tephra', NULL, NULL, '2021-04-08 13:11:17.332566');
INSERT INTO public.soil_type VALUES (3, 'Taupo Sand', 'Immature Orthic Pumice Soil', 'Typic Udivitrand', '2021-04-08 13:11:17.332561');
INSERT INTO public.soil_type VALUES (4, 'Tauherenikau Shallow Silt Loam', 'Typic Orthic Brown Soil', 'Dystric Ustochrept', '2021-04-08 13:11:17.332669');
INSERT INTO public.soil_type VALUES (5, 'Tamahere silt loam', 'Artifact Fill Anthropic Soil', 'Typic Udivitrand', '2021-04-08 13:11:17.332628');
INSERT INTO public.soil_type VALUES (6, 'Takapau Sandy Loam', 'Typic Orthic Allophanic Soil', 'Andic Ustochrept', '2021-04-08 13:11:17.332415');
INSERT INTO public.soil_type VALUES (7, 'Taihape Steepland Soils Uneroded', 'Mottled Argillic Pallic Soil', 'Aquic Haplustalf', '2021-04-08 13:11:17.332664');
INSERT INTO public.soil_type VALUES (8, 'Taihape Steepland Soils - Eroded', 'Mottled Immature Pallic Soil', 'Aeric Epiaquept', '2021-04-08 13:11:17.332659');
INSERT INTO public.soil_type VALUES (9, 'Te Anau Sandy Loam', 'Fragic Allophanic Brown Soil', 'Andic Dystrochrept', '2021-04-08 13:11:17.33251');
INSERT INTO public.soil_type VALUES (10, 'Silverdale silt loam and clay loam', 'Mottled Orthic Brown Soil', 'Oxyaquic Kanhapludalf', '2021-04-08 13:11:17.332623');
INSERT INTO public.soil_type VALUES (11, 'Rukuhia peat', 'Acid Fibric Organic Soil', 'Hemic Medifibrist', '2021-04-08 13:11:17.332618');
INSERT INTO public.soil_type VALUES (12, 'Rotomahana Loam', 'Typic Tephric Recent Soil', 'Typic Udorthent', '2021-04-08 13:11:17.332314');
INSERT INTO public.soil_type VALUES (13, 'Rapaura Shallow Silt Loam', 'Typic Fluvial Recent Soil', 'Mollic Ustifluvent', '2021-04-08 13:11:17.332433');
INSERT INTO public.soil_type VALUES (14, 'Ramiha Silt Loam', 'Acidic Allophanic Brown Soil', 'Andic Haplumbrept', '2021-04-08 13:11:17.332546');
INSERT INTO public.soil_type VALUES (15, 'Puhoi Clay Loam', 'Mottled-acidic Orthic Brown Soil', 'Mollic Haplaquept', '2021-04-08 13:11:17.332277');
INSERT INTO public.soil_type VALUES (16, 'Poporangi Sandy Loam', 'Mottled Duric Pallic Soil', 'TypicDurustalf', '2021-04-08 13:11:17.33241');
INSERT INTO public.soil_type VALUES (17, 'Pomahaka Loamy Silt on Sandy Loam', 'Fluvial Recent Soil', 'Typic Udifluvent', '2021-04-08 13:11:17.332505');
INSERT INTO public.soil_type VALUES (18, 'Seddon Silt Loam', 'Typic Immature Pallic Soil', 'Udic Ustochrept', '2021-04-08 13:11:17.332438');
INSERT INTO public.soil_type VALUES (19, 'Te Kopuru Sand', 'Humus-pan Densipan Podzol', 'Typic Duraquod', '2021-04-08 13:11:17.332469');
INSERT INTO public.soil_type VALUES (20, 'Te Kowhai silt loam', 'Typic Orthic Gley', 'Typic Ochraqualf', '2021-04-08 13:11:17.332633');
INSERT INTO public.soil_type VALUES (21, 'Te Kowhai, brown subsoil variant', 'Typic Orthic Gley', 'Typic Ochraqualf', '2021-04-08 13:11:17.332639');
INSERT INTO public.soil_type VALUES (22, 'Whangaripo Clay', 'Mottled Yellow Ultic Soil', 'Typic Hapludult', '2021-04-08 13:11:17.332207');
INSERT INTO public.soil_type VALUES (23, 'Whakawai Hill Soil', 'Typic Orthic Brown Soil', 'Umbric Dystrochrept', '2021-04-08 13:11:17.332383');
INSERT INTO public.soil_type VALUES (24, 'Waita Loamy Sand', 'Typic Orthic Podzol Soil', 'Typic Haplorthod', '2021-04-08 13:11:17.332705');
INSERT INTO public.soil_type VALUES (25, 'Wairau Deep Silt Loam', 'Typic Fluvial Recent Soil', 'Mollic Ustifluvent', '2021-04-08 13:11:17.332443');
INSERT INTO public.soil_type VALUES (26, 'Waipahihi Sand', 'Immature Orthic Pumice Soil', 'Typic Udivitrand', '2021-04-08 13:11:17.332576');
INSERT INTO public.soil_type VALUES (27, 'Waimate North Heavy Silt Loam', 'Typic Orthic Oxidic Soil', 'Andeptic haplohumult', '2021-04-08 13:11:17.332474');
INSERT INTO public.soil_type VALUES (28, 'Waikare Clay', 'Perch-gleyed Albic Ultic Soil', 'Aquic Haplohumult', '2021-04-08 13:11:17.332269');
INSERT INTO public.soil_type VALUES (29, 'Waiherere Silt Loam', 'Weathered Fluvial Recent Soil', 'Mollic Udifluvent', '2021-04-08 13:11:17.332378');
INSERT INTO public.soil_type VALUES (30, 'Timaru Silt Loam', 'Mottled Fragic Pallic Soil', 'Udic Haplustept', '2021-04-08 13:11:17.332352');
INSERT INTO public.soil_type VALUES (31, 'Tihoi Loamy Sand', 'Humose Orthic Podzol', 'Andic Haplorthod', '2021-04-08 13:11:17.332571');
INSERT INTO public.soil_type VALUES (32, 'Temuka Clay Loam', 'Typic Orthic Gley Soil', 'Mollic Endoaquept', '2021-04-08 13:11:17.332347');
INSERT INTO public.soil_type VALUES (33, 'Templeton Silt Loam', 'Typic Immature Pallic Soil', 'Udic Haplustept', '2021-04-08 13:11:17.332342');
INSERT INTO public.soil_type VALUES (34, 'Tekoa Steepland Soil', 'Allophanic Firm Brown Soil', 'Andic Dystrudept', '2021-04-08 13:11:17.332337');
INSERT INTO public.soil_type VALUES (35, 'Te Rapa peaty or humic silt loam brown subsoil variant', 'Humose Orthic Podzol', 'Humic Haplorthod', '2021-04-08 13:11:17.332644');
INSERT INTO public.soil_type VALUES (36, 'Te Rapa peaty or humic silt loam', 'Humose Groundwater - gley Podzol', 'Humic Aquic Haplorthod', '2021-04-08 13:11:17.332649');
INSERT INTO public.soil_type VALUES (37, 'Te Puke Sandy Loam', 'Typic Orthic Allophanic Soil', 'Typic Hapludand', '2021-04-08 13:11:17.332327');
INSERT INTO public.soil_type VALUES (38, 'Te Ngae Road', NULL, NULL, '2021-04-08 13:11:17.332319');
INSERT INTO public.soil_type VALUES (39, 'Paroa Silt Loam', 'Acid Recent Gley Soils', 'Andic or Aquic Dystrochrept', '2021-04-08 13:11:17.332309');
INSERT INTO public.soil_type VALUES (40, 'Papamoa Loamy Sand', 'Typic Sandy Recent Soil', 'Typic Udipsamment', '2021-04-08 13:11:17.332304');
INSERT INTO public.soil_type VALUES (41, 'Papakauri Silt Loam', 'Typic Orthic Allophanic Soil', 'Acrudoxic Hapludand', '2021-04-08 13:11:17.332464');
INSERT INTO public.soil_type VALUES (42, 'Oruataiaka Hill Soil', 'Typic Orthic Recent Soils', 'Typic Udorthent', '2021-04-08 13:11:17.332389');
INSERT INTO public.soil_type VALUES (43, 'Kini Peat', 'Acid Humic Organic Soil', 'Typic Medisaprist', '2021-04-08 13:11:17.33269');
INSERT INTO public.soil_type VALUES (44, 'Kerikeri Friable Clay', 'Orthic Typic Oxidic Soil', 'Typic Haplohumult', '2021-04-08 13:11:17.332453');
INSERT INTO public.soil_type VALUES (45, 'Kaweka Sandy Silt', 'Typic Impeded Allophanic Soil', 'Typic Hapludand', '2021-04-08 13:11:17.3324');
INSERT INTO public.soil_type VALUES (46, 'Kairanga Silty Clay', 'Typic Orthic Gley Soil', 'Typic Endoaquept', '2021-04-08 13:11:17.332525');
INSERT INTO public.soil_type VALUES (47, 'Kaingaroa Sand', 'Welded Impeded Pumice Soil', 'Typic Udivitrand', '2021-04-08 13:11:17.332551');
INSERT INTO public.soil_type VALUES (48, 'Hurunui Hill and Steepland Soil', 'Acidic Orthic Brown Soil', 'Typic Dystrudept', '2021-04-08 13:11:17.332357');
INSERT INTO public.soil_type VALUES (49, 'Horotiu silt loam', 'Typic Orthic Allophanic Soil', 'Typic Udivitrand', '2021-04-08 13:11:17.332602');
INSERT INTO public.soil_type VALUES (50, 'Hochstetter Fine Sandy Loam', 'Acidic-mafic Allophanic Brown Soil', 'Typic Dystrochrept', '2021-04-08 13:11:17.33268');
INSERT INTO public.soil_type VALUES (51, 'Hamilton clay loam', 'Typic Orthic Granular Soil', 'Typic Haplohumult', '2021-04-08 13:11:17.332597');
INSERT INTO public.soil_type VALUES (52, 'Grovetown Deep Clay Loam', 'Mottled Fluvial Recent Soil', 'Aquic Dystrochrept', '2021-04-08 13:11:17.332423');
INSERT INTO public.soil_type VALUES (53, 'Foxton Black Sand', 'Typic Sandy Brown Soils', 'Typic Udipsamment', '2021-04-08 13:11:17.33252');
INSERT INTO public.soil_type VALUES (54, 'Egmont Black Loam', 'Typic Orthic Allophanic Soil', 'Typic Hapludand', '2021-04-08 13:11:17.332515');
INSERT INTO public.soil_type VALUES (55, 'Dunstan', 'Typic Allophanic Brown Soil', 'Andic Lithic Dystrochrept', '2021-04-08 13:11:17.332484');
INSERT INTO public.soil_type VALUES (56, 'Bruntwood silt loam pale subsoil variant', 'Typic Gley Allophanic Soil', 'Aquic Hapludand', '2021-04-08 13:11:17.332592');
INSERT INTO public.soil_type VALUES (57, 'Bruntwood silt loam', 'Typic Impeded Allophanic Soil', 'Aquic Hapludand', '2021-04-08 13:11:17.332581');
INSERT INTO public.soil_type VALUES (58, 'Bluff Clay', 'Calcareous Orthic Melanic Soil', 'Typic Rendoll', '2021-04-08 13:11:17.332395');
INSERT INTO public.soil_type VALUES (59, 'Awatere Shallow Sandy Loam', 'Typic Fluvial Recent Soil', 'Typic Ustifluvent', '2021-04-08 13:11:17.332448');
INSERT INTO public.soil_type VALUES (60, 'Kiore Hill Soil', 'Typic Orthic Brown Soil', 'Typic Dystrochrept', '2021-04-08 13:11:17.332368');
INSERT INTO public.soil_type VALUES (61, 'Wharekaka Silt Loam', 'Mottled Fragic Pallic Soil', 'Aeric Fragiaquept', '2021-04-08 13:11:17.332674');
INSERT INTO public.soil_type VALUES (62, 'Kopuawhara Loamy Sand', 'Typic Orthic Allophanic', 'Typic Hapludand', '2021-04-08 13:11:17.332373');
INSERT INTO public.soil_type VALUES (63, 'Kumara Soils', 'Silt-mantled Perch-gley Podzol', 'Typic Alaquod', '2021-04-08 13:11:17.332695');
INSERT INTO public.soil_type VALUES (64, 'Oruanui Sand', 'Podzolic Orthic Pumice soil', 'Andic Haplorthod', '2021-04-08 13:11:17.332556');
INSERT INTO public.soil_type VALUES (65, 'Opuha Silt Loam', 'Mottled Fragic Pallic Soil', 'Aquic Fragiochrept', '2021-04-08 13:11:17.332499');
INSERT INTO public.soil_type VALUES (66, 'Opouriao Silt Loam', ' Weathered Fluvial Recent Soil', 'Dystric Fluventic Eutrochrept', '2021-04-08 13:11:17.332298');
INSERT INTO public.soil_type VALUES (67, 'Omahu Gravelly Sandy Loam', 'Typic Fluvial Recent Soil', 'Typic Ustifluvent', '2021-04-08 13:11:17.332405');
INSERT INTO public.soil_type VALUES (68, 'Okaihau Gravelly Clay', 'Nodular Typic Oxidic Soil', 'Orthoxic Palehumult', '2021-04-08 13:11:17.332459');
INSERT INTO public.soil_type VALUES (69, 'Oamaru Shallow Clay Loam', 'Typic Rendzic Melanic Soil', 'Lithic Rendol', '2021-04-08 13:11:17.332494');
INSERT INTO public.soil_type VALUES (70, 'Moutoa Humic Clay', 'Acidic Recent Gley Soil', 'Fluvaquentic Endoaquoll', '2021-04-08 13:11:17.332541');
INSERT INTO public.soil_type VALUES (71, 'Motumaoho Silty Peat', 'Acid Humic Organic Soil', 'Terric Medisaprist', '2021-04-08 13:11:17.332613');
INSERT INTO public.soil_type VALUES (72, 'Moana Soils', 'Typic Perchgley Podzol', 'Typic Epiaquod', '2021-04-08 13:11:17.3327');
INSERT INTO public.soil_type VALUES (73, 'Matangi silt loam', 'Typic Sandy Gley Soil', 'Aquantic Humaquept', '2021-04-08 13:11:17.332608');
INSERT INTO public.soil_type VALUES (74, 'Marton Silt Loam', 'Argillic-fragic Perch-gley Pallic Soil', 'Aeric Kandiaqualf', '2021-04-08 13:11:17.332535');
INSERT INTO public.soil_type VALUES (75, 'Mapua Fine Sandy Loam', 'Mottled Yellow Ultic Soil', 'Aquic Hapludult', '2021-04-08 13:11:17.332428');
INSERT INTO public.soil_type VALUES (76, 'Manawatu Silt Loam', 'Weathered Fluvial Recent Soil', 'Dystric Fluventic Eutrochrept', '2021-04-08 13:11:17.33253');
INSERT INTO public.soil_type VALUES (77, 'Mamaku Sandy Loam', 'Humose Orthic Podzol', 'NZ: Humose Orthic Podzol', '2021-04-08 13:11:17.332282');
INSERT INTO public.soil_type VALUES (78, 'Lowburn Loamy Sand', 'Typic Agedargillic Semiarid Soil', 'Arenic Haplargid', '2021-04-08 13:11:17.332489');
INSERT INTO public.soil_type VALUES (79, 'Lismore Shallow and Stony Silt Loam', 'Pallic Orthic Brown Soil', 'Typic Dystrustept', '2021-04-08 13:11:17.332332');
INSERT INTO public.soil_type VALUES (80, 'Lewis Steepland Soil', 'Typic Orthic Podzol Soil', 'Andic Haplorthod', '2021-04-08 13:11:17.332363');
INSERT INTO public.soil_type VALUES (81, 'Kourarau Hill Soils', 'Typic Rendzic Melanic Soil', 'Lithic Rendoll', '2021-04-08 13:11:17.332654');
INSERT INTO public.soil_type VALUES (82, 'Wharekohe Silt Loam', 'Densipan Perched-gley Ultic Soil', 'Typic Albaquult', '2021-04-08 13:11:17.332479');


--
-- Data for Name: species; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.species VALUES (1, 'Barley', 'Hordeum vulgare', 'BA', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (2, 'Perennial ryegrass', 'Lolium perenne', 'PR', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (3, 'Persian clover', 'Trifolium resupinatum', 'PERC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (4, 'Phalaris', 'Phalaris arundinacea', 'PHAL', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (5, 'Plantain', 'Plantago lanceolata', 'PLAN', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (6, 'Red clover', 'Trifolium pratense', 'RC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (7, 'Rose clover', 'Trifolium hirtum', 'ROC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (8, 'Russell Lupin', 'Lupinus polyphyllus', 'RLUP', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (9, 'Rye', 'Secale cereale', 'RYE', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (10, 'Sainfoin', 'Onobrychis vicifolia', 'SA', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (11, 'Smooth brome', 'Bromus inermis', 'SB', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (12, 'Snail medic', 'Medicago scutellata', 'SNM', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (13, 'Sorghum', 'Sorghum bicolor', 'SO', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (14, 'Paspalum', 'Paspalum dilatatum', 'PASP', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (15, 'Sphere medic', 'Medicago sphaerocarpos', 'SPM', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (16, 'Spotted medic', 'Medicago arabica', 'SM', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (17, 'Strand medic', 'Medicago litorallis', 'STM', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (18, 'Strawberry clover', 'Trifolium fragiferum', 'STC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (19, 'Sub clover', 'Trifolium subterraneum', 'SC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (20, 'Suckling clover ', 'Trifolium dubium', 'SUC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (21, 'Sulla', 'Hedisarum coronarium', 'SUL', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (22, 'Sweet vernal', 'Anthoxanthum odoratum', 'SV', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (23, 'Tall fescue', 'Festuca arundinacea', 'TF', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (24, 'Timothy', 'Phleum pratense', 'TIM', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (25, 'Triticale', 'Triticum aestivum', 'TRI', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (26, 'White clover', 'Trifolium repens', 'WC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (27, 'White sweetclover', 'Melilotus albus', 'WSC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (28, 'Spineless burr medic', 'Medicago polymorpha var brevispina', 'SBM', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (29, 'Woolly burr medic', 'Medicago minima', 'WBM', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (30, 'Oat', 'Avena sativa', 'OA', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (31, 'Maize', 'Zea mays', 'MA', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (32, 'Balansa', 'Trifolium michelianum', 'BAL', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (33, 'Arrowleaf', 'Trifolium vesiculosum', 'AL', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (34, 'Alsike clover', 'Trifolium hybridum', 'ASC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (35, 'Barrel medic', 'Medicago trunculata', 'BM', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (36, 'Berseem clover', 'Trifolium alexandrinum', 'BC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (37, 'Berseem clover', 'Trifolium alexandrinum', 'BEC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (38, 'Birdsfoot trefoil', 'Lotus corniculatus', 'BFT', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (39, 'Black medic', 'Medicago lupulina', 'BLAM', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (40, 'Burr medic', 'Medicago polymorpha var polymorpha', 'BM', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (41, 'Caucasian clover', 'Trifolium ambiguum', 'CC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (42, 'Chicory', 'Cichorium intybus', 'CHIC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (43, 'Cluster clover', 'Trifolium glomeratum', 'CLUC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (44, 'Mountain brome', 'Bromus marginatus', 'MB', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (45, 'Cocksfoot', 'Dactylis glomerata', 'CF', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (46, 'Crimson clover', 'Trifolium incarnatum', 'CRIC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (47, 'Durum', 'Triticum durum', 'DU', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (48, 'Fodder Beet', 'Beta vulgaris', 'FB', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (49, 'Goose grass', 'Bromus hordeaceus', 'GG', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (50, 'Haresfoot clover', 'Trifolium arvense', 'HF', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (51, 'Hybrid ryegrass', 'Lolium perenne', 'HRG', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (52, 'Italian ryegrass', 'Lolium multiflorum', 'IRG', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (53, 'Kikuyu', 'Pennisetum clandestinum', 'KI', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (54, 'Lentil', 'Lens culinaris', 'LEN', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (55, 'Lotus', 'Lotus pedunculatus', 'LOT', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (56, 'Lucerne', 'Medicago sativa', 'LUC', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (57, 'Lupin annual', 'Lupinus ssp.', 'LUP', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (58, 'Crested dogstail', 'Cynosurus cristatus', 'DOGS', '2021-03-31 04:25:29.541789');
INSERT INTO public.species VALUES (59, 'Yorkshire fog', 'Holcus lanatus', 'YF', '2021-03-31 04:25:29.541789');


--
-- Data for Name: treatment_type; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.treatment_type VALUES (6, 'Irrigation', 'Irrigation', true, 1, 'mm/yr', '2021-03-25 23:05:44.533931', true, 3);
INSERT INTO public.treatment_type VALUES (7, 'Dominant species', 'Dominant species', true, 1, NULL, '2021-03-31 04:25:29.465699', true, 2);
INSERT INTO public.treatment_type VALUES (9, 'Additional species', 'Additional species', true, 3, NULL, '2021-03-31 04:25:29.465699', true, 2);
INSERT INTO public.treatment_type VALUES (8, 'Dominant species - Cultivar(s)', 'Dominant species - Cultivar(s)', true, 2, NULL, '2021-03-31 04:25:29.465699', true, 2);
INSERT INTO public.treatment_type VALUES (10, 'Additional species - Cultivar(s)', 'Additional species - Cultivar(s)', true, 4, NULL, '2021-03-31 04:25:29.465699', true, 2);
INSERT INTO public.treatment_type VALUES (1, 'Nitrogen', 'kgNyr', true, 1, 'KgN/ha', '2021-03-25 23:05:44.533931', true, 1);
INSERT INTO public.treatment_type VALUES (2, 'Phosphorus', 'kgPyr', true, 2, 'KgP/ha', '2021-03-25 23:05:44.533931', true, 1);
INSERT INTO public.treatment_type VALUES (3, 'Potassium', 'kgKyr', true, 3, 'KgK/ha', '2021-03-25 23:05:44.533931', true, 1);
INSERT INTO public.treatment_type VALUES (5, 'Lime', 'kgLimeyr', true, 5, 'KgLime/ha', '2021-03-25 23:05:44.533931', true, 1);
INSERT INTO public.treatment_type VALUES (4, 'Sulphur', 'kgSyr', true, 4, 'KgS/ha', '2021-03-25 23:05:44.533931', true, 1);


--
-- Name: soil_type_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."soil_type_Id_seq"', 82, true);


--
-- Name: species_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."species_Id_seq"', 59, true);


--
-- Name: treatment_type_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."treatment_type_Id_seq"', 10, true);


--
-- PostgreSQL database dump complete
--

