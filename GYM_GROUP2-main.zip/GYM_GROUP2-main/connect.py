dbuser = "postgres"
dbpass = "comp639!" #"PUT YOUR PASSWORD HERE"
dbhost = "comp639.cldqh6d4e9ir.us-east-1.rds.amazonaws.com" #"PUT YOUR AWS Connect String here"
dbport = "5432"
dbname = "comp639"


# dbuser = "postgres"
# dbpass = "xxxxxxxxxx" #"PUT YOUR PASSWORD HERE"
# dbhost = "localhost" #"PUT YOUR AWS Connect String here"
# dbport = "5432"
# dbname = "test_group"