# Student name: Chiyu He (Finn) ;   Student ID: 1147535 

dbuser = "chiyuhe"
dbpass = "Liu91Guang01" #"PUT YOUR PASSWORD HERE"
dbhost = "chiyuhe-comp636.cwzwqfvyur9y.us-east-1.rds.amazonaws.com" #"PUT YOUR AWS Connect String here"
dbport = "5432"
dbname = "activitynight"